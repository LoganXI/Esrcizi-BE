﻿namespace Hotel.Models
{
    public class TipologiaCamera
    {
        public int Id { get; set; }
        public string Tipologia { get; set; }
        public decimal TariffaBase { get; set; }
    }

}

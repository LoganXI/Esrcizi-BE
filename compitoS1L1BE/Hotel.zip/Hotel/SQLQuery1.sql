﻿INSERT INTO Trattamenti (Descrizione, TariffaSupplementare) VALUES
('Mezza Pensione', 20.00),
('Pensione Completa', 40.00),
('Pernottamento con Colazione', 10.00);
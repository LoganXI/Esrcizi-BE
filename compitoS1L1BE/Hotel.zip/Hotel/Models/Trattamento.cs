﻿namespace Hotel.Models
{
    public class Trattamento
    {
        public int Id { get; set; }
        public string Descrizione { get; set; }
        public decimal TariffaSupplementare { get; set; }
    }

}
